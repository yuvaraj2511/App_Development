package com.example.demo.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
