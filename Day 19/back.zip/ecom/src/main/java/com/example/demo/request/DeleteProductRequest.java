package com.example.demo.request;

public class DeleteProductRequest {
	
//	private Long 

}
