package com.example.demo.response;

public class CreatePaymentLinkResponse {
	
	

}
