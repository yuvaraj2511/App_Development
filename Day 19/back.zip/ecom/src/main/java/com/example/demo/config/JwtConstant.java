package com.example.demo.config;

public class JwtConstant {
	
	public static final String SECRET_KEY="jbjbjeogucugru9bgoiegbruggiargborbgaouibgourgbugbuorbgouubgoiue";
	public static final String JWT_HEADER="Authorization";

}
